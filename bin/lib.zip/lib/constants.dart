import 'package:flutter/material.dart';


const int kPlasicWeight = 40;
const int kPaperWeight = 25;
const int kMetalWeight = 60;