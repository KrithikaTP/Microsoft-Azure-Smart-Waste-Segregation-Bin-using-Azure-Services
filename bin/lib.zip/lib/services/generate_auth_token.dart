import 'dart:io';
import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:cryptoutils/cryptoutils.dart';


class GenerateAuthToken {
  String verb = 'GET';
  String resourceType = 'docs';

  String date = HttpDate.format(DateTime.now());
  String masterKey =
      '3CF1FIj6ECD9q7DGQaPqj6IG0ZklpU5VrA6nwltwaUswzKA5Ji3l7oZeQCy7t6S6VPI8hVidjoNXOFUAklVSoQ==';
  String keyType = "master";
  String tokenVersion = "1.0";
  String resourceId = 'dbs/Bin_Users/colls/users/docs/123456';

  Map<String,String> createToken() {

//    print(date);
    String payload = verb.toLowerCase() +
        '\n' +
        resourceType.toLowerCase() +
        '\n' +
        resourceId +
        '\n' +
        date.toLowerCase() +
        '\n' +
        '' +
        '\n';

    List<int> messageBytes = utf8.encode(payload);
    List<int> key = utf8.encode(masterKey);
    Hmac hmac = new Hmac(sha256, key);
    Digest digest = hmac.convert(messageBytes);
//    print(digest);
    String base64 = CryptoUtils.bytesToBase64(digest.bytes);
//    print(base64);
    String authToken = Uri.encodeComponent('type='+ keyType + '&ver=' + tokenVersion + '&sig=' + base64);
    return {'authToken':authToken,'date':date};

  }
}
